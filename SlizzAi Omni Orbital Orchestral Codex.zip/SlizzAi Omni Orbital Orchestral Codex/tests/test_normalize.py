from services.harps.normalize import to_si
def test_celsius_to_kelvin():
    v,u = to_si("temp", 0.0, "C")
    assert abs(v-273.15) < 1e-6 and u == "K"