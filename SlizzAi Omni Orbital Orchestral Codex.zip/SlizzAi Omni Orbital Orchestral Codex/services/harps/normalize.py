SI = {"W": 1.0, "kW": 1000.0, "C": 1.0, "K": 1.0, "m": 1.0, "km": 1000.0}
def to_si(name: str, value: float, unit: str) -> tuple[float,str]:
    factor = SI.get(unit, None)
    if factor is None: raise ValueError(f"unknown unit {unit}")
    if unit == "C": return (value + 273.15, "K")
    return (value * factor, list(SI.keys())[list(SI.values()).index(1.0)])